// script.js

// Load webcam
navigator.mediaDevices.getUserMedia({ video: true })
  .then(stream => {
    document.getElementById('webcam').srcObject = stream;
  }).catch(err => {
    console.error("Webcam access denied:", err);
  });

window.onload = () => {
  fetch('/get-questions')
    .then(res => res.json())
    .then(data => {
      const form = document.getElementById('exam-form');
      data.forEach((q, i) => {
        const qDiv = document.createElement('div');
        qDiv.innerHTML = `<p><strong>${i + 1}. ${q.question}</strong></p>`;
        q.options.forEach(opt => {
          qDiv.innerHTML += `
            <label>
              <input type="radio" name="${i}" value="${opt}"> ${opt}
            </label><br>
          `;
        });
        form.appendChild(qDiv);
      });
    });

  // Start monitoring
  fetch('/start-monitoring', { method: 'POST' });
};

function submitExam() {
  const formData = new FormData(document.getElementById('exam-form'));
  const answers = {};
  for (let [key, value] of formData.entries()) {
    answers[key] = value;
  }

  fetch('/submit-exam', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ answers })
  }).then(res => res.json()).then(data => {
    document.getElementById('score-display').innerText = `You scored ${data.score}/15`;
  });
}
