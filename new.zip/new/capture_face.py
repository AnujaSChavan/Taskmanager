import cv2

def capture_face_image():
    cam = cv2.VideoCapture(0)
    print("[INFO] Press 's' to save your face image as 'known_face.jpg'.")

    while True:
        ret, frame = cam.read()
        if not ret:
            print("[ERROR] Failed to access webcam.")
            break

        cv2.imshow("Capture Face", frame)

        # Press 's' to save image
        if cv2.waitKey(1) & 0xFF == ord('s'):
            cv2.imwrite("known_face.jpg", frame)
            print("[INFO] Image saved as 'known_face.jpg'")
            break

    cam.release()
    cv2.destroyAllWindows()

if __name__ == "__main__":
    capture_face_image()
