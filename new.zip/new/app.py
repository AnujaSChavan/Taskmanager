from flask import Flask, request, jsonify
from flask_cors import CORS
import json
import os

from proctoring_modules import (
    start_proctoring,
    stop_proctoring,
    get_score,
    log_event,
    generate_report
)

app = Flask(__name__)
CORS(app)  # Enable CORS for frontend communication

# Start proctoring system
@app.route('/start', methods=['POST'])
def start():
    start_proctoring()
    return jsonify({"message": "Proctoring started"})

# Stop proctoring system
@app.route('/stop', methods=['POST'])
def stop():
    stop_proctoring()
    return jsonify({"message": "Proctoring stopped"})

# Submit quiz answers
@app.route('/submit', methods=['POST'])
def submit():
    user_answers = request.json.get("answers", {})
    score = get_score(user_answers)
    return jsonify({"score": score})

# Get proctoring logs
@app.route('/log', methods=['GET'])
def get_log():
    try:
        with open("proctoring_log.csv", "r") as file:
            data = file.read()
        return jsonify({"log": data})
    except Exception as e:
        return jsonify({"error": str(e)})

# Generate report
@app.route('/report', methods=['GET'])
def report():
    try:
        generate_report()
        return jsonify({"message": "Report printed to console."})
    except Exception as e:
        return jsonify({"error": str(e)})

# Home route
@app.route('/', methods=['GET'])
def home():
    return jsonify({"message": "Proctoring API is live!"})

if __name__ == '__main__':
    app.run(debug=True)
