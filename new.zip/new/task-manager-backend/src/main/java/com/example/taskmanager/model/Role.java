package com.example.taskmanager.model;

public enum Role {
	USER
}

