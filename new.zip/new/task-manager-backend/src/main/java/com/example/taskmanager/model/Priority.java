package com.example.taskmanager.model;

public enum Priority {
	HIGH,
	MEDIUM,
	LOW
}

