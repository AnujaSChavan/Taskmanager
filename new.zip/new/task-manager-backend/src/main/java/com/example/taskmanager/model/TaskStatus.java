package com.example.taskmanager.model;

public enum TaskStatus {
    PENDING,
    IN_PROGRESS,
    COMPLETED
}


