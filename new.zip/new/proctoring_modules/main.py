import threading
import os
import datetime
import json
import time

from .logger_module import log_event
from .audio_module import monitor_audio
from .screen_module import monitor_screen
from .webcam_module import monitor_webcam

# Global flag to control threads
monitoring_active = False

# Function to handle the stopping of monitoring threads
def stop_monitoring_threads():
    global monitoring_active
    monitoring_active = False
    log_event('Proctoring system stopped', event_type="INFO")

# Start proctoring system
def start_proctoring():
    global monitoring_active
    monitoring_active = True

    log_event('Proctoring system started', event_type="INFO")

    # Start webcam, audio, and screen monitoring in parallel threads
    webcam_thread = threading.Thread(target=monitor_webcam)
    audio_thread = threading.Thread(target=monitor_audio)
    screen_thread = threading.Thread(target=monitor_screen)

    webcam_thread.start()
    audio_thread.start()
    screen_thread.start()

    # Monitor status and ensure threads are alive
    while monitoring_active:
        time.sleep(1)  # Keep checking if monitoring is still active

    # Stop the threads once monitoring is stopped
    webcam_thread.join()
    audio_thread.join()
    screen_thread.join()

# Stop proctoring system
def stop_proctoring():
    global monitoring_active
    monitoring_active = False
    log_event('Proctoring system stopped', event_type="INFO")

# Score calculation function
def get_score(user_answers):
    try:
        with open('questions.json') as f:
            questions = json.load(f)

        score = 0
        for i, question in enumerate(questions):
            if str(i) in user_answers and user_answers[str(i)] == question['correct']:
                score += 1

        log_event(f'User completed test with score: {score}/{len(questions)}', event_type="INFO")
        return score

    except Exception as e:
        log_event(f'Error calculating score: {str(e)}', event_type="SUSPICIOUS")
        return 0
