from .audio_module import detect_speech
from .logger_module import log_event, log_suspicious_activity
from .screen_module import monitor_screen
from .webcam_module import monitor_webcam
from .main import start_proctoring, stop_proctoring, get_score
