import cv2
import face_recognition
import time
from .logger_module import log_event

def monitor_webcam():
    try:
        video_capture = cv2.VideoCapture(0)
        known_image = face_recognition.load_image_file("known_face.jpg")
        known_face_encoding = face_recognition.face_encodings(known_image)[0]

        cooldown = 10
        last_logged = {"no_face": 0, "multiple_faces": 0, "face_mismatch": 0}

        while True:
            ret, frame = video_capture.read()
            if not ret:
                log_event("Webcam Error: Unable to access webcam")
                break

            rgb_frame = frame[:, :, ::-1]
            face_locations = face_recognition.face_locations(rgb_frame)
            face_encodings = face_recognition.face_encodings(rgb_frame, face_locations)

            current_time = time.time()

            if len(face_encodings) == 0:
                if current_time - last_logged["no_face"] > cooldown:
                    log_event("No face detected.")
                    last_logged["no_face"] = current_time
            elif len(face_encodings) > 1:
                if current_time - last_logged["multiple_faces"] > cooldown:
                    log_event("Multiple faces detected.")
                    last_logged["multiple_faces"] = current_time
            else:
                match = face_recognition.compare_faces([known_face_encoding], face_encodings[0])[0]
                if not match and current_time - last_logged["face_mismatch"] > cooldown:
                    log_event("Unrecognized face detected.")
                    last_logged["face_mismatch"] = current_time

            time.sleep(1)

        video_capture.release()
        cv2.destroyAllWindows()

    except Exception as e:
        log_event(f"Webcam monitoring error: {str(e)}")
