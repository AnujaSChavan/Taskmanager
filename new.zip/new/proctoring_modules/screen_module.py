import pyautogui
import time

def monitor_screen():
    previous_title = ""
    while True:
        current_title = pyautogui.getActiveWindowTitle()
        suspicious = current_title and previous_title and current_title != previous_title
        previous_title = current_title
        yield suspicious
        time.sleep(3)
