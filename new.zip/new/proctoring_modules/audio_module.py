import speech_recognition as sr
from .logger_module import log_event

def detect_speech():
    r = sr.Recognizer()
    with sr.Microphone() as source:
        try:
            audio = r.listen(source, timeout=3)
            text = r.recognize_google(audio)
            if text:
                log_event("Speech detected.")
        except sr.UnknownValueError:
            pass
        except sr.WaitTimeoutError:
            pass
