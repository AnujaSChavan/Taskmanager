import cv2
import face_recognition
from .logger_module import log_event  # Importing log_event from logger module

def authenticate_user():
    video = cv2.VideoCapture(0)
    print("Look at the camera for authentication...")

    known_face_encodings = []  # Replace with saved encodings for real use

    count = 0
    authenticated = False

    while count < 10:
        ret, frame = video.read()
        if not ret:
            break

        rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        faces = face_recognition.face_encodings(rgb)

        if faces:
            # In real use, match face here
            authenticated = True
            break

        count += 1
        cv2.waitKey(100)

    video.release()

    if authenticated:
        log_event("User authenticated successfully")
    else:
        log_event("Authentication failed")

    return authenticated
